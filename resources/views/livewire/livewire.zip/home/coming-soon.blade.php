<div style="background-image: url('{{ asset('storage/app/public/landing-image.jpg') }}'); background-size: cover; background-attachment: fixed; height: 100vh;">
   

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Lacrostini">
  <meta name="author" content="Lacrostini">
      <!-- CSRF Token -->
	  <meta name="csrf-token" content="{{ csrf_token() }}">

  <title>Lacrostini</title>

 <!-- Bootstrap css -->

 <link rel="stylesheet" href="{{asset('assets/customer')}}/css/bootstrap.css?v=2.0"> 
 <!-- <link href="css/bootstrap.css?v=2.0" rel="stylesheet" type="text/css" /> -->
 <link href="{{asset('assets/customer')}}/css/bootstrap.css?v=2.0" rel="stylesheet" type="text/css" />

<!-- Custom css -->
<link href="{{asset('assets/customer')}}/css/ui.css?v=2.0" rel="stylesheet" type="text/css" />
<!-- <link href="css/ui.css?v=2.0" rel="stylesheet" type="text/css" /> -->

<link href="{{asset('assets/customer')}}/css/responsive.css?v=2.0" rel="stylesheet" type="text/css" />

<!-- Font awesome 5 -->
<link href="{{asset('assets/customer')}}/fonts/fontawesome/css/all.min.css" type="text/css" rel="stylesheet">
<!-- <link href="fonts/fontawesome/css/all.min.css" type="text/css" rel="stylesheet"> -->

</head>



<div class="container">
    <div class="column">
    @php($store_logo=\App\Model\BusinessSetting::where(['key'=>'logo'])->first()->value)
				<div class="col-lg-2 col-sm-4 col-4">
					<a href="" class="navbar-brand">
						<img class="logo" height="40" src="{{asset('storage/store/'.$store_logo)}}">
						<!-- <img class="logo" height="40" src="storage/app/public/store/2024-01-12-65a0803383f0c.png"> -->

					</a> <!-- Logo end.// -->
				</div>
        <div class="text">Text 1</div>
        <div class="text">Text 2</div>
        <div class="text">Text 3</div>
    </div>
</div>


<style>
    .content {
    background-color: rgba(255, 255, 255, 0.8); /* Add background color for better readability */
    padding: 20px;
}

.column {
    text-align: center;
}

.text {
    margin-bottom: 20px;
    font-size: 24px;
}

</style>

</div>
